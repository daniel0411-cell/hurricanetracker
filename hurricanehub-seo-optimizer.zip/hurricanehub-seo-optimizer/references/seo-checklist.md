# SEO 检查项与改法（按 P1/P2/P3 分级）

按 AGENTS.md 的分级约定：**P1** 性能 / 内链，**P2** 多媒体 / i18n，**P3** 整洁度。commit message 用 `P1-x` / `P2-x` / `P3-x` 前缀。

---

## Meta 标签（title / description / canonical / OG）

改动入口：`src/components/SEO.astro`，以及各页面传入 `SEO` 的 props。

- title：50–60 字符，主关键词前置，避免全站重复；模板 `{页面主题} | HurricaneHub`。
- description：140–160 字符，含主关键词 + 行动价值，禁止截断句、禁止与 title 逐字重复。
- canonical：必须绝对 URL、`https://www.` 前缀、带尾斜杠。已由 `normalizeCanonical()` 统一处理——不要在页面里手写非规范 URL 绕过它。
- OG / Twitter：`og:title`、`og:description`、`og:image`（1200×630 绝对 URL）、`og:type`、`twitter:card=summary_large_image`。缺图时 fallback 到 `/images/og/default-og.png`。
- `lastModified`：内容更新后同步 `dateModified`，否则 `src/data/site.ts` 的 `contentLastModified` 会让全站显示同一时间，削弱新鲜度信号。

验证：`npm run metadata:audit`。

---

## 结构化数据（JSON-LD）

改动入口：`src/lib/schema.ts` 的构造器 + 页面传入的 `jsonLd`。

- 首页 / 全站：`WebSite`（含 `SearchAction`）+ `Organization`。
- 所有页面：`BreadcrumbList`（`SEO.astro` 已按 URL 路径自动生成，检查 name 是否可读、不是 slug 直译）。
- 博客文章：`Article` / `BlogPosting`，含 `headline`、`image`、`datePublished`、`dateModified`、`author`、`publisher`。
- 含 FAQ 的页面：`FAQPage`，问答必须与页面可见文本一致（否则违规）。
- 工具页：可用 `WebApplication` / `SoftwareApplication`。
- 多个 schema 用 `graph()` 合并为 `@graph`，不要输出多个独立 script 造成冲突。

验证：`npm run schema:audit`。禁止为不存在于页面上的内容打标记。

---

## Sitemap / robots / RSS

`src/pages/sitemap*.ts` 是**禁区文件**，不得直接改。需要新增页面进入 sitemap 时，改数据源 `src/lib/sitemapRoutes.ts` 或对应的 `src/data/*.ts` 集合，让分片自动纳入。

- 确认新增路由已出现在 `sitemap-pages/-blog/-locations/-tools` 之一，且 `sitemap-index.xml` 收录该分片。
- URL 必须与 canonical 完全一致（https + www + 尾斜杠），不得出现 301 目标之外的旧路径。
- `robots.txt.ts`：确认 `Sitemap:` 指向 `sitemap-index.xml`，不要误屏蔽 `/api/`（部分接口是页面渲染依赖）以外的目录。
- RSS：`npm run rss:audit` 通过，item 含标题/链接/pubDate/description。

线上验证：部署后 `npm run verify:seo`。

---

## 内链（P1 重点）

- 消除孤岛页：每个页面至少有 2 个来自其他页面的入链。用 `npm run links:audit` 找孤岛。
- 集群互链：州页 ↔ 城市页 ↔ 主题页 ↔ 博客文章，按 `src/data/contentClusters.ts` 的簇关系补链。
- 锚文本用描述性关键词，禁止「点击这里」「阅读更多」。
- 内链组件优先复用 `StateTrackerSeoLinks.astro`、`StateActionPaths.astro`，不要在页面里散写一次性链接块。
- 博客相关文章由 `getRelatedPosts()` 的 TF-IDF 相似度自动产出，无需逐篇配置。
- 每个页面正文内链 3–8 条为宜，不要为凑数堆链接。

---

## 图片与多媒体（P2）

- 每张内容图必须有描述性 `alt`（含关键词但不堆砌），装饰图用 `alt=""`。
- 显式 `width`/`height` 防 CLS；首屏图 `loading="eager"` + `fetchpriority="high"`，其余 `loading="lazy"` + `decoding="async"`。
- 博客 hero 必须是**摄影写实风格 PNG**（`public/images/blog/{slug}.png`），同时保留同名 `.svg` 占位供 `gen-og.mjs` 生成 OG 图。不要用 AI 感明显的 SVG 插画当 hero。

验证：`npm run media:audit`。

---

## 性能（P1）

- 关键 CSS 内联、非关键 JS 延后；避免在 `BaseLayout` 引入阻塞渲染的第三方脚本。
- Leaflet / 图表等重组件按需 `client:visible` 或动态 import，不要全站加载。
- 字体：`display=swap`、预连接必要域名，避免 FOIT。
- 图片走 PNG/WebP 合理尺寸，不要用超大原图缩放显示。

---

## 内容质量（P3 / 内容层）

- 薄内容页（<300 词）补充实用信息或合并，用 `npm run content:audit` 定位。
- 每个页面单一 `<h1>`，H2/H3 层级不跳级。
- FAQ 与正文不重复堆砌同一段话。
- 关键词覆盖用 `npm run seo:keywords` 检查，避免多页争抢同一主关键词（自我竞争）。

---

## i18n / hreflang（P2，需授权）

涉及 `astro.config.mjs` 的 i18n、hreflang、redirects 配置属于**边缘授权**范围：必须先取得用户明确授权再改。相关目录 `src/i18n/`。

---

## 收尾核对

1. `npm run build` 通过（`astro check` 无 error）。
2. 复跑本次相关审计脚本，问题数下降、无新增回归。
3. 只 `git add` 本次改动文件，commit message 带 P 级前缀。
4. 确认 post-commit hook 已把 HEAD 推到 origin/main。
