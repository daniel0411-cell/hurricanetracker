# HurricaneHub 项目地图（SEO 视角）

项目根目录：`/Users/daniel/Documents/hurricanetracker`
站点：https://www.hurricanetracker.cc （Astro 7 + @astrojs/cloudflare，部署为 Cloudflare **Worker**，非 Pages）

## SEO 相关关键文件

| 关注点 | 文件 |
|---|---|
| 全站 meta / canonical / OG / Twitter / JSON-LD 注入 | `src/components/SEO.astro` |
| 页面外壳（head、字体、主题、全局 CSS） | `src/layouts/BaseLayout.astro`、`src/layouts/Layout.astro` |
| 结构化数据构造器（website / organization / breadcrumb / article / faq） | `src/lib/schema.ts` |
| 站点常量（name、url、canonicalUrl、contentLastModified） | `src/data/site.ts` |
| sitemap 路由集合来源 | `src/lib/sitemapRoutes.ts` |
| sitemap 入口与分片 | `src/pages/sitemap.xml.ts`、`sitemap-index.xml.ts`、`sitemap-pages/-blog/-locations/-tools.xml.ts`（**禁区，勿改**） |
| robots / RSS / 搜索索引 | `src/pages/robots.txt.ts`、`src/pages/rss.xml.ts`、`src/pages/search-index.json.ts` |
| 博客数据（BlogPost[] 数组，非 Markdown） | `src/data/blog.ts` |
| 州 / 城市 / 主题 / 风暴页数据 | `src/data/stateSeo.ts`、`cities.ts`、`states.ts`、`topicPages.ts`、`stormPages.ts`、`contentClusters.ts`、`trackerSlugs.ts` |
| 内链组件 | `src/components/StateTrackerSeoLinks.astro`、`StateActionPaths.astro`、`Footer.astro` |
| FAQ 区块 | `src/components/FaqBlock.astro` |
| 重定向 / 规范化 | `src/middleware.ts` |
| OG 图片生成 | `scripts/gen-og.mjs`（prebuild 阶段自动跑，依赖 `public/images/blog/{slug}.svg` 占位） |

`SEO.astro` 的 props：`title`、`description`、`canonical`、`siteName`、`jsonLd?`、`lastModified?`、`image?`、`ogImage?`。canonical 会被强制规范化为 `https://www.<host>/…`（补 www、补协议、补首页斜杠），改 canonical 逻辑前先读这段。

## 审计脚本全清单（`npm run <script>`）

| 命令 | 作用 |
|---|---|
| `seo:audit` | 站点级 SEO 综合体检 |
| `metadata:audit` | title / description / canonical / OG 完整性与长度 |
| `schema:audit` | JSON-LD 结构化数据校验 |
| `links:audit` | 内链密度、孤岛页、死链 |
| `seo:opportunities` | 优化机会排序报告 |
| `seo:keywords` | 关键词覆盖度 |
| `content:audit` | 正文长度 / 重复度 / 薄内容 |
| `faq:audit` | FAQ 覆盖与格式 |
| `media:audit` | 图片 alt、尺寸、格式 |
| `coverage:audit` | 页面类型覆盖度 |
| `rss:audit` | RSS 有效性 |
| `search:audit` | 站内搜索索引 |
| `verify:seo` | **线上**探测 sitemap/robots/RSS 等入口（部署后用） |
| `seo:full` | build + 上面几乎全部审计（耗时长，谨慎使用） |

## 构建与发布

- `npm run build` = prebuild（`verify:city-data` + `gen-og.mjs`）→ `astro build`；`npm run check` 单跑 `astro check`。
- 内联 client script 会被类型检查；DOM 密集脚本按项目约定加 `// @ts-nocheck`。
- `npm run deploy` = `wrangler deploy --config wrangler.deploy.toml` → `verify:seo` → IndexNow → Google Indexing（后两者 best-effort）。
- `npm run ship -- "msg"` = 校验在 main 分支 → build → commit → fetch/落后检查 → push（3 次重试）→ deploy。**会一并部署上线**，仅在用户明确要求发布时使用。

## 已知坑（务必遵守）

1. **Git 网络**：本机（Mac Mini，用户 `daniel`）只能通过 WorkBuddy 沙箱代理访问 github。**沙箱 Bash + 保留代理环境 → 200 OK；非沙箱 Bash + 代理环境 → 502**。所以 git/gh 网络操作走默认（沙箱）Bash 且**不要** `env -u` 代理。
2. **wrangler 反例**：`wrangler deploy` 上传大量静态资源时必须 `env -u HTTP_PROXY -u HTTPS_PROXY`，与 git 相反。
3. **`gh` 不在 PATH**：用 `~/.local/bin/gh`。凭据已写入 `~/.config/gh/hosts.yml`（PAT），**不要重跑 `gh auth login`**，会覆盖可用凭据。
4. **post-commit hook** 自动 `git push origin main`（带 3 次重试）。commit 后不必手动 push，但要确认推送结果。
5. **Node fetch 忽略代理**：Node 22 全局 fetch（undici）不读 `HTTPS_PROXY`。跑 `gindex` 需用 `setGlobalDispatcher(new ProxyAgent(...))` 包装器，且包装器必须放在项目目录内（ESM 不认 NODE_PATH）。
6. **Google Indexing 配额**：服务账号每天 200 次 publish。全量 sitemap ≈73 URL，一天两次部署即耗尽，之后全部 429 `RESOURCE_EXHAUSTED`。优先只提交新增/变更 URL。
7. **macOS 无 GNU `timeout`**，不要使用。
8. **代码/配置只用 ASCII 直引号**。
9. **Worker 服务端出站**受限：`api.weather.gov`、`hazards.fema.gov` 等政府源在服务端被代理拦截，外部数据抓取优先放客户端。
10. **边缘缓存**：SSR HTML 缓存 TTL 短，验证新部署加 `?v=<时间戳>`，不要用 purge_cache。
11. **状态页规范路径**：`/tracker/{state}/`（静态）；旧 `/hurricane-tracker/[state]` 由 `src/middleware.ts` 301；城市页保留 `/hurricane-tracker/city/{slug}/`。
12. **不要安装 `@astrojs/sitemap`**：sitemap 是自定义实现。
