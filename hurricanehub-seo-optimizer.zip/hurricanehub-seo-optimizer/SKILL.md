---
name: hurricanehub-seo-optimizer
description: 【显示名：HurricaneHub SEO优化】Optimize SEO for the HurricaneHub hurricane tracking site (hurricanetracker.cc, Astro + Cloudflare Worker). This skill should be used when the user asks to improve SEO, fix meta tags/titles/descriptions, repair sitemap or robots, add structured data (JSON-LD), strengthen internal links, fix canonical/hreflang, or run SEO audits for the hurricane site. Trigger keywords: SEO优化, 飓风站, meta标签, sitemap, 内链, 结构化数据, schema, canonical, robots, SEO审计.
agent_created: true
---

# HurricaneHub SEO 优化

## 用途

在 HurricaneHub（`/Users/daniel/Documents/hurricanetracker`，Astro + Cloudflare Worker，站点 hurricanetracker.cc）上执行 SEO 优化任务：诊断 → 直接改文件 → 构建 → 推送。本技能强调**执行**而非讨论，产出是已落地的代码改动，不是建议清单。

## 适用场景

- 用户要求优化飓风站的 SEO、提升收录或排名。
- 修复 meta 标签、title、description、canonical、OG/Twitter 卡片。
- 修复或扩展 sitemap、robots、RSS。
- 补充结构化数据（Article / FAQPage / BreadcrumbList / WebSite）。
- 强化内链、修复孤岛页、补 alt 文本、优化 LCP/CLS。
- 跑 SEO 审计并按报告修复问题。

## 硬性执行规则（不可协商）

1. **启动第一步：必须读取 `/Users/daniel/Documents/hurricanetracker/AGENTS.md`**，以该文件为项目规范的最高来源。若其内容与本技能冲突，以 AGENTS.md 为准。
2. **直接修改文件**。使用 Edit/Write 落地改动，**不要在回复里贴完整代码或整段 diff**。
3. **不解释、不提问、不确认**。不做方案铺垫、不复述改动原理、不征求同意后再动手。直接改。
4. **改完必须运行构建并推送 Git**（见「收尾流程」）。构建不通过就不算完成，必须修到通过。
5. **禁区文件**（绝对不得随意修改）：`src/pages/` 核心路由文件、`src/pages/sitemap.xml.ts`、`package.json` 依赖、`wrangler*.toml` 及部署配置、`gcp-sa.json`。
6. **唯一允许打断的例外**：改动必须触碰 `astro.config.mjs`（如 i18n / hreflang / redirects）或上述禁区文件时——此时停下，一句话说明要改什么、为什么，等用户明确授权。除此之外一律不提问。
7. **安全**：绝不输出、复制或转述 `gcp-sa.json` 内容；不解压覆盖 `hurricanehub-blog-publisher.zip`（仅归档）。

## 工作流程

1. **读规范**：读 `AGENTS.md`。
2. **定位问题**：优先用现成审计脚本而非手工翻页面。选最相关的 1–3 个跑（全量脚本清单见 `references/project-map.md`）：
   ```bash
   cd /Users/daniel/Documents/hurricanetracker
   npm run seo:audit          # 站点级 SEO 体检
   npm run metadata:audit     # title/description/canonical/OG
   npm run schema:audit       # JSON-LD 结构化数据
   npm run links:audit        # 内链与孤岛页
   npm run seo:opportunities  # 优化机会排序
   ```
   任务范围大或不确定时才跑 `npm run seo:full`（含 build，耗时长）。
3. **分级命名改动**：按 AGENTS.md 约定归类 —— **P1** 性能/内链，**P2** 多媒体/i18n，**P3** 整洁度。commit message 与进度描述沿用该前缀（如 `P1-5 …`）。
4. **直接改文件**：改 `src/components/`、`src/layouts/`、`src/data/`、`src/utils/` 等非禁区文件。具体检查项与改法见 `references/seo-checklist.md`。
5. **构建验证**：`npm run build`（先 `astro check` 再 `astro build`）。内联 client script 报类型错时，给该 `<script>` 加 `// @ts-nocheck`（项目既有约定）。
6. **复跑审计**：重跑第 2 步用过的脚本，确认问题数下降、无新增回归。
7. **提交推送**：见下。

## 收尾流程（构建 + 推送）

默认路径（只推 GitHub，不部署）：

```bash
cd /Users/daniel/Documents/hurricanetracker
npm run build
git add <本次改动的文件>          # 不要 git add -A 卷入无关改动
git commit -m "P1-x 简短英文描述"   # post-commit hook 会自动 push origin main
```

- Git 网络必须走**沙箱 Bash + 保留代理环境变量**，不要 `env -u` 代理，否则 github 返回 502。
- `gh` 不在 PATH，需要时用全路径 `~/.local/bin/gh`。
- 推送后用 `git log --oneline -1` 与 `git status` 确认 HEAD 与 origin/main 一致。

用户明确要求「上线/发布/部署」时才走全量发布（会额外跑 wrangler deploy + IndexNow + Google Indexing，wrangler 可能要求授权）：

```bash
npm run ship -- "P1-x 简短英文描述"
```

## 交付格式

改完只回一段极简小结：改了哪些文件（路径列表）、审计指标前后对比、commit hash。不贴代码、不写长篇说明。

## 参考资料

- `references/project-map.md` —— 审计脚本全清单、关键文件位置、构建/推送/索引提交的已知坑（代理、Node fetch、Google 配额）。
- `references/seo-checklist.md` —— meta / sitemap / schema / 内链 / 图片 / 性能的具体检查项与改法，按 P1/P2/P3 分级。
